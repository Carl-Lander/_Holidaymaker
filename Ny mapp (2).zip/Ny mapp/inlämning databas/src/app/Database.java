package app;

import tableclasses.Company;
import tableclasses.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;

public class Database {
    private Scanner scanner;
    Connection con = null;
    String url = "jdbc:sqlite:C:/Users/visio/Desktop/Ny mapp/inlämning databas/src/databas/holidaymaker12.db";


    public Database() {
        this.scanner = new Scanner(System.in);
        this.RunApp();
        this.getCustomer();
        this.connect();
        this.getCustomer();
        this.getCompany();
        this.menu();
        selectCustomer();
        viewCompany();
        bookingCustomer();
        roomSize();
    }
    public void selectCustomer() {
        String sql = "SELECT * FROM Customer";
        try (
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID:    Name:        Address:");
                System.out.println(rs.getString("Customer_ID") + "\t" + rs.getString("First_Name")+","
                        + rs.getString("Last_Name")+ "\t" + rs.getString("Address") + "\n--------------------------------------------------------------------");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void viewCompany(){
            String sql = "SELECT First_name, Last_name, Address, Country, City, Phone_number, Email, Birth_date FROM Customer WHERE Company_ID = '2'";
            try(
                    Statement stmt = con.createStatement();
                    ResultSet rs = stmt.executeQuery(sql)){
                while (rs.next()){
                    System.out.println("Customers with company of 3:\n");
                    System.out.println("Name:                   Address:                             PhoneNumber:              Email:");
                    System.out.println(rs.getString("First_Name")+ " " + rs.getString("Last_Name")+"\t" + "\t"+ rs.getString("Address")+"\t"+
                            rs.getString("Country")+ "\t" + rs.getString("City")+"\t"+"\t"+ rs.getString("Phone_Number")+"\t"+ rs.getString("Email")+
                            "\n"+ "-----------------------------------------------------------------------------------------------------------------------------------------");
                }
            }catch (SQLException e) {
                System.out.println(e.getMessage());
            }
    }

    public void bookingCustomer() {
        String sql = "SELECT Customer.First_Name, Customer.Last_Name, Booking.Booking_ID, Calendar.Calendar_ID, Calendar.Room_ID, Room.Room_Name, Hotel.Hotel_Name, Calendar.Check_In, Calendar.Check_out " +
                "FROM Booking " +
                "INNER JOIN Customer ON Customer.Customer_ID = Booking.Customer_ID " +
                "INNER JOIN Calendar ON Calendar.Calendar_ID = Booking.Calendar_ID " +
                "INNER JOIN Room ON Room.Room_ID = Calendar.Room_ID " +
                "INNER JOIN Hotel ON Hotel.Hotel_ID = Room.Hotel_ID " +
                "WHERE Customer.Customer_ID = 1";
        try (
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("Checking booking of Aidan Prose\n");
                System.out.println("Name:        BookingID  CalendarID    RoomID  RoomNr               Hotel Name                Check_In       Check_Out");
                System.out.println(rs.getString("First_Name")+ " " + rs.getString("Last_Name")+"\t"+"\t" +rs.getString("Booking_ID")+"\t"+
                       "\t"+"\t" + rs.getString("Calendar_ID")+"\t" +"\t"+"\t"+ rs.getString("Room_ID")+ "\t"+"\t"+rs.getString("Room_Name")+ "\t"+ "\t"+"\t"+rs.getString("Hotel_Name")+"\t"+"\t"+ rs.getString("Check_In")+
                        "\t"+"\t"+rs.getString("Check_out"));

            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    public void roomSize() {
        String sql = "SELECT Room.Room_ID, Room.room_name, Room.room_size, Hotel.Hotel_ID, Hotel.Hotel_Name, Hotel.City, Hotel.Country FROM Room " +
                "INNER JOIN Calendar ON Room.Room_ID = Calendar.Room_ID " +
                "INNER JOIN Hotel ON Hotel.Hotel_ID = Room.Hotel_ID " +
                "WHERE Room.Room_Size = 3 AND Calendar.Calendar_ID NOT IN date_control OR Calendar.Calendar_ID IS NULL " +
                "GROUP BY Room.Room_ID ORDER BY Hotel.Hotel_ID";
        try (
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("Rooms with size 3:\n");
                System.out.println("RoomID  Number  size  HotelID             Hotel name             City        Country ");
                System.out.println(rs.getString("Room_ID")+"\t"+"\t"+rs.getString("room_name")+"\t"+"\t"+rs.getString("room_size")+"\t"+"\t"+rs.getString("Hotel_ID")+"\t"+"\t"+"\t"+rs.getString("Hotel_Name")+"\t"+
                        "\t"+rs.getString("City")+"\t"+"\t"+rs.getString("Country")+"\t");
                System.out.println("\n");

            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    public void hotelAmenities(){
        String sql = "SELECT DISTINCT * FROM Room " +
                "INNER JOIN Hotel ON Hotel.Hotel_ID = Room.Hotel_ID " +
                "INNER JOIN Amenity ON Hotel.Hotel_ID = Amenity.Hotel_ID " +
                "INNER JOIN Amenity_Info ON Amenity.Amenity_ID = Amenity_Info.Amenity_ID " +
                "LEFT JOIN Calendar ON Room.Room_ID = Calendar.Room_ID AND Calendar.Check_Out <= '2022-07-10' AND Calendar.Check_In >= '2022-07-01'" +
                "WHERE Calendar.Calendar_ID IS NULL AND Amenity_Info.Description = 'Evening Entertainent' OR Amenity_Info.Description = 'Pool'";
        try(
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("HotelID         Hotel Name       amenities");
                System.out.println("\t"+rs.getString("Hotel_ID")+"\t"+ rs.getString("Hotel_Name")+"\t"+
                        rs.getString("Description")+"\t");
                System.out.println("\n");
            }
    }catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void insertTo(String First_Name,String Last_Name) {

        try {
            PreparedStatement statement = con.prepareStatement("INSERT INTO Customer (First_Name, Last_Name) VALUES(?,?)");
            statement.setString(1,First_Name);
            statement.setString(2,Last_Name);
            ResultSet rs = statement.executeQuery();
            System.out.println(rs);
        } catch (SQLException e) {
            System.out.println("ssss");
            System.out.println(e.getMessage());
        }
    }


    public void RunApp() {
        int option;
        boolean keepAlive = true;
        while (keepAlive) {
            System.out.println("\n|1| Connect to database   |2| Select customer from list    |3| View company   |4| Check booking   |5| More options");

            option = Integer.parseInt(scanner.nextLine());
            switch (option) {
                case 1:
                    //createCustomer();
                    connect();
                    break;
                case 2:
                    selectCustomer();
                    break;
                    //getCustomer();
                    //createBooking();
                case 3:
                    viewCompany();
                    //Customers();
                    break;
                case 4:
                    bookingCustomer();
                    break;
                case 5:
                    menu();
                    break;
            }
        }
    }

    public void menu() {
        int option;
        boolean keepAlive = true;
        while (keepAlive) {
            System.out.println("|1| Available room with size   |2| Hotels with pool  |3| Find customer   |4| main menu");
            option = Integer.parseInt(scanner.nextLine());
            switch (option) {
                case 1:
                    roomSize();
                    break;
                case 2:
                    hotelAmenities();
                    break;
                case 3:
                    bookingCustomer();
                    break;
                case 4:
                    RunApp();
                case 5:
                    insertTo("carl","Lander");
            }
        }
    }

    public void connect() {
        try {
            con = DriverManager.getConnection(url);
            Statement statement = con.createStatement();
            System.out.println(" Hotel Database Connected..\n --------");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public ArrayList<Company> getCompany() {
        ArrayList<Company> companies = new ArrayList<>();
        String query = "SELECT * FROM Company";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("Company_ID");
                String name = resultSet.getString("Company_Name");
                companies.add(new Company(id, name));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return companies;
    }

    public ArrayList<Customer> getCustomer() {
        ArrayList<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";

        try {
            String url = "jdbc:sqlite:C:/Users/visio/Desktop/Ny mapp/inlämning databas/src/databas/holidaymaker12.db";
            con = DriverManager.getConnection(url);
            PreparedStatement statement = con.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int customerID = resultSet.getInt("Customer_ID");
                String firstName = resultSet.getString("First_Name");
                String lastName = resultSet.getString("Last_Name");
                String adress = resultSet.getString("Address");
                String city = resultSet.getString("City");
                String country = resultSet.getString("Country");
                String phoneNumber = resultSet.getString("Phone_Number");
                String email = resultSet.getString("Email");
                String birthDate = resultSet.getString("Birth_Date");
                int companyID = resultSet.getInt("Company_ID");
                customers.add(new Customer(customerID, firstName, lastName, adress, city, country, phoneNumber, email, birthDate, companyID));

            }
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        return getCustomer();
    }

    public int createCompany(String companyName) {
        int createID1 = 0;
        String query = "INSERT INTO Company(Company_Name) VALUES(?)";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, companyName);
            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();
            while (keys.next()) {
                createID1 = keys.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return createID1;
    }

    public void viewAmeneties(int hotelID) {
        String query = "SELECT Amenity_Info.Amenity_ID, Hotel.Hotel_ID, Hotel.Hotel_Name, Description FROM Amenity_Info\n" +
                "INNER JOIN Hotel ON Hotel.Hotel_ID = Aminity.Hotel_ID\n" +
                "INNER JOIN Amenity ON Amenity.Amenity_ID = Amenity_Info.Amenity_ID\n" +
                "WHERE Hotel.Hotel_ID = '" + hotelID + "'\n" +
                "GROUP BY Amenity_Info.Description ";
        try {
            Statement statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("Hotel ID    Hotel Name    Amenity ID    Description");
            while (resultSet.next()) {
                String title = resultSet.getString("Hotel_Name");
                int amenityID = resultSet.getInt("Amenity_ID");
                String description = resultSet.getString("Description");
                System.out.println(hotelID + "          " + title + "         " + amenityID + "        " + description);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public int createCustomer(int companyID, String firstName, String lastName, String adress,
                              String city, String country, String phoneNumber, String email,
                              String birthday) {
        int customerID = 0;
        String query = "INSERT INTO Customer(First_Name, Last_Name, Adress, City, Country, PhoneNumber, Email, Birthday, Company_ID" +
                "VALUES (?,?,?,?,?,?,?,?,?);";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, adress);
            statement.setString(4, city);
            statement.setString(5, country);
            statement.setString(6, phoneNumber);
            statement.setString(7, email);
            statement.setString(8, birthday);
            statement.setInt(9, companyID);

            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();
            while (keys.next()) {
                customerID = keys.getInt(1);
            }
            System.out.println("[Customer ADDED!]. Customer ID: " + customerID + " .Customer name: " + firstName + " " + lastName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return customerID;
    }

    public boolean findAvailableRoom(int roomSize, String checkInDate, int hotelID, String checkOutDate) {
        boolean isEmpty = true;
        String query = "SELECT Room.Room_ID,Room.Room_Name,Room.Room_Size,Hotel.Hotel_ID,Hotel.Hotel_Name," +
                "Hotel.City,Hotel.Country,Room.Price FROM Room\n" +
                "LEFT JOIN Calendar ON Room.Room_ID = Calendar.Room_ID\n" +
                "INNER JOIN Hotel ON Hotel.Hotel_ID = Room.Hotel_ID\n" +
                "WHERE Room.Room_Size = ? AND Hotel.Hotel_ID = ? AND Calendar.CheckOut_Date <= ?\n" +
                "OR Room.Room_Size = ? AND Hotel.Hotel_ID = ? AND Calendar.CheckIn_Date >= ?\n" +
                "OR Room.Room_Size = ? AND Hotel.Hotel_ID = ? AND Calendar.Calendar_ID IS NULL\n" +
                "GROUP BY Room.Room_ID ORDER BY Hotel.Hotel_ID";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, roomSize);
            statement.setInt(2, hotelID);
            statement.setString(3, checkOutDate);
            statement.setInt(4, roomSize);
            statement.setInt(5, hotelID);
            statement.setString(6, checkInDate);
            statement.setInt(7, roomSize);
            statement.setInt(8, hotelID);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                System.out.println("RoomID    RoomName   RoomSize   HotelID   HotelName   City   Country   Price");
                isEmpty = false;
                int roomID = resultSet.getInt("Room_ID");
                String roomName = resultSet.getString("Room_Name");
                int roomSize1 = resultSet.getInt("Room_Size");
                String hotelID1 = resultSet.getString("Hotel_ID");
                String hotelName = resultSet.getString("Hotel_Name");
                String city = resultSet.getString("City");
                String country = resultSet.getString("Country");
                int price = resultSet.getInt("Price");
                System.out.println(roomID + "     " + roomName + "     " + roomSize1 + "     " + hotelID1 + "     " + hotelName + "    " +
                        city + "      " + country + "      " + price);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        if (isEmpty) {
            System.out.println("There are no room available.. ");
            return false;
        }
        return true;
    }

    public int createBooking(int customerID, int calendarID) {
        int bookingID = 0;
        String query = "INSERT INTO Booking(Customer_ID,Calendar_ID) VALUES(?,?)";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, customerID);
            statement.setInt(2, calendarID);
            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();

            while (keys.next()) {
                bookingID = keys.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bookingID;
    }

    public int creatCalendar(String checkInDate, String checkOutDate, int roomID) {
        int calendarID = 0;
        String query = "INSERT INTO Calendar(CheckIn_Date,CheckOut_Date,Room_ID) VALUES(?,?)";

        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, checkInDate);
            statement.setString(2, checkOutDate);
            statement.setInt(3, roomID);

            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();

            while (keys.next()) {
                calendarID = keys.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return calendarID;
    }
}
