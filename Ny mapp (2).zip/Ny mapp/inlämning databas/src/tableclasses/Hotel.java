package tableclasses;

public class Hotel {
    public int hotelID;
    public String name;
    public String city;
    public String country;
    public int distanceToBeach;
    public int distanceToCenter;

    public Hotel(int hotelID, String name, String city, String country,int distanceToBeach,int distanceToCenter){
        this.hotelID = hotelID;
        this.name = name;
        this.city = city;
        this.country = country;
        this.distanceToBeach = distanceToBeach;
        this.distanceToCenter = distanceToCenter;
    }
}
