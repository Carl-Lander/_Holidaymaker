package tableclasses;

public class Company {
    public int companyID;
    public String companyName;

    public Company(int companyID, String companyName){
        this.companyID = companyID;
        this.companyName = companyName;
    }
}
