package tableclasses;

public class Customer {
    public int customerID;
    public String firstName;
    public String lastName;
    public String adress;
    public String city;
    public String country;
    public String phoneNumber;
    public String email;
    public String birthDate;
    public int companyID;

    public Customer(int customerID, String firstName, String lastName, String adress, String city, String country
    , String phoneNumber, String email, String birthDate, int companyID){
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.adress = adress;
        this.city = city;
        this.country = country;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.birthDate = birthDate;
        this.companyID = companyID;
    }

}
